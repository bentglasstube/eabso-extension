this.manifest = {
  "name": "eab.so shortener",
  "icon": "../../icon48.png",
  "settings": [
    {
      "tab": "Main",
      "group": "",
      "name": "username",
      "type": "text",
      "label": "Post as",
      "text": "Some asshole"
    },
    {
      "tab": "Main",
      "group": "",
      "name": "keybind",
      "type": "text",
      "label": "Shortcut key",
      "text": "^S",
    }
  ]
};

