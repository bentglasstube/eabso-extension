this.manifest = {
  "name": "eab.so shortener",
  "icon": "../../icon.png",
  "settings": [
    {
      "tab": "Main",
      "group": "",
      "name": "username",
      "type": "text",
      "label": "Post as",
      "text": "Some asshole"
    },
    { 
      "tab": "Main",
      "group": "",
      "name": "hidden",
      "type": "checkbox",
      "label": "Hide links from RSS feed"
    } 
  ]
};

